import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split, Subset
import yaml
import os
import glob
import numpy as np
import pickle
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import GroupKFold

from src.epi_data_pipeline import EPIGenomicDataset
from src.dataset import EPIDataset
from src.model import Kansformer
from src.encoding import POCD_ND_Encoder
from src.visualize import plot_history

# 1. Setup
with open('configs/config.yaml') as f: config = yaml.safe_load(f)
os.makedirs(config['paths']['save_dir'], exist_ok=True)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Device: {device}")

# 2. Prepare Encoder
print("Initializing POCD-ND Encoder...")
encoder = POCD_ND_Encoder(k=config['data']['kmer_size'])
# Fit with dummy sequences (encoder learns kmer statistical profiles)
np.random.seed(42)
dummy_pos = ["".join(np.random.choice(['A','C','G','T'], config['data']['sequence_length'])) for _ in range(50)]
dummy_neg = ["".join(np.random.choice(['A','C','G','T'], config['data']['sequence_length'])) for _ in range(50)]
encoder.fit(dummy_pos, dummy_neg, config['data']['sequence_length'])

with open(f"{config['paths']['save_dir']}/encoder.pkl", 'wb') as f:
    pickle.dump(encoder, f)
print("Encoder saved.")

# 3. Data Loading
bengi_dir = config['paths'].get('bengi_dir', './data/BENGI')
feats_config = config['paths'].get('feats_config', '')
ref_genome = config['paths'].get('ref_genome', '')

# Find BENGI TSV files
bengi_files = sorted(
    glob.glob(os.path.join(bengi_dir, '*.tsv.gz')) +
    glob.glob(os.path.join(bengi_dir, '*.tsv'))
)

USE_REAL_DATA = len(bengi_files) > 0 and os.path.exists(feats_config)

if USE_REAL_DATA:
    print(f"\n=== REAL DATA MODE ===")
    print(f"BENGI files: {len(bengi_files)}")
    for f_path in bengi_files:
        print(f"  {os.path.basename(f_path)}")

    # Create genomic dataset (reads BENGI + loads .pt signals)
    genomic_ds = EPIGenomicDataset(
        bengi_paths=bengi_files,
        feats_config_path=feats_config,
        feats_order=config['data'].get('feats_order', None),
        seq_len=config['data'].get('seq_len_bp', 2_500_000),
        bin_size=config['data'].get('bin_size', 500),
        enhancer_window=config['data'].get('enhancer_window', 3000),
        promoter_window=config['data'].get('promoter_window', 3000),
        ref_genome_path=ref_genome if ref_genome else None,
    )

    # Wrap with POCD-ND encoding
    dataset = EPIDataset(config, encoder, source_dataset=genomic_ds)

    # Split by chromosome (GroupKFold)
    valid_chroms = config['training'].get('valid_chroms', ['chr11', 'chr17'])
    chroms = genomic_ds.get_chrom_groups()
    train_idx = [i for i, c in enumerate(chroms) if c not in valid_chroms]
    val_idx = [i for i, c in enumerate(chroms) if c in valid_chroms]

    if len(val_idx) == 0:
        # Fallback: random 80/20 split
        n = len(dataset)
        train_size = int(0.8 * n)
        perm = np.random.permutation(n)
        train_idx = perm[:train_size].tolist()
        val_idx = perm[train_size:].tolist()

    train_set = Subset(dataset, train_idx)
    val_set = Subset(dataset, val_idx)
    print(f"Train: {len(train_set)}, Val: {len(val_set)} "
          f"(held-out chroms: {valid_chroms})")

else:
    print(f"\n=== SYNTHETIC DATA MODE ===")
    print(f"BENGI dir '{bengi_dir}' not found or feats_config missing.")
    print(f"Using synthetic data for pipeline testing.")
    dataset = EPIDataset(config, encoder, num_synthetic=200)
    train_size = int(0.8 * len(dataset))
    train_set, val_set = random_split(dataset, [train_size, len(dataset)-train_size])

num_workers = config['training'].get('num_workers', 0)
train_loader = DataLoader(train_set, batch_size=config['data']['batch_size'],
                          shuffle=True, num_workers=num_workers)
val_loader = DataLoader(val_set, batch_size=config['data']['batch_size'],
                        num_workers=num_workers)

# 4. Model & Optimizer
model = Kansformer(config).to(device)
optimizer = optim.Adam(model.parameters(), lr=config['training']['lr'])
crit_cls = nn.BCELoss()
crit_reg = nn.MSELoss()

total_params = sum(p.numel() for p in model.parameters())
train_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"\nModel: {total_params:,} params ({train_params:,} trainable)")

# 5. Training Loop
train_loss_hist, val_loss_hist = [], []
best_val_loss = float('inf')
patience_counter = 0

print(f"\nStarting Training for {config['training']['epochs']} epochs...")
for epoch in range(config['training']['epochs']):
    model.train()
    epoch_loss = 0
    
    for batch in train_loader:
        seq = batch['seq'].float().to(device)
        epi = batch['epi'].float().to(device)
        lbl = batch['label'].float().to(device)
        dst = batch['dist'].float().to(device)
        
        optimizer.zero_grad()
        p_cls, p_reg = model(seq, epi)
        
        loss = crit_cls(p_cls, lbl) + (config['training']['lambda_dist'] * crit_reg(p_reg, dst))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), config['training'].get('grad_clip', 1.0))
        optimizer.step()
        epoch_loss += loss.item()
        
    # Validation
    model.eval()
    val_loss = 0
    all_preds, all_labels = [], []
    with torch.no_grad():
        for batch in val_loader:
            seq = batch['seq'].float().to(device)
            epi = batch['epi'].float().to(device)
            lbl = batch['label'].float().to(device)
            dst = batch['dist'].float().to(device)
            p_cls, p_reg = model(seq, epi)
            val_loss += (crit_cls(p_cls, lbl) + config['training']['lambda_dist'] * crit_reg(p_reg, dst)).item()
            all_preds.extend(p_cls.cpu().numpy().flatten())
            all_labels.extend(lbl.cpu().numpy().flatten())
            
    avg_train = epoch_loss / max(len(train_loader), 1)
    avg_val = val_loss / max(len(val_loader), 1)
    train_loss_hist.append(avg_train)
    val_loss_hist.append(avg_val)
    
    # Metrics
    preds_np = np.array(all_preds)
    labels_np = np.array(all_labels)
    acc = accuracy_score(labels_np, (preds_np > 0.5).astype(int))
    try:
        auc = roc_auc_score(labels_np, preds_np)
    except ValueError:
        auc = 0.0
    
    print(f"Epoch {epoch+1}/{config['training']['epochs']} | "
          f"Train: {avg_train:.4f} | Val: {avg_val:.4f} | "
          f"Acc: {acc:.4f} | AUC: {auc:.4f}")
    
    # Save best model
    if avg_val < best_val_loss:
        best_val_loss = avg_val
        torch.save(model.state_dict(), f"{config['paths']['save_dir']}/model_best.pth")
        patience_counter = 0
    else:
        patience_counter += 1
    
    if patience_counter >= config['training'].get('patience', 999):
        print(f"Early stopping at epoch {epoch+1}")
        break

# 6. Save
torch.save(model.state_dict(), f"{config['paths']['save_dir']}/model_final.pth")
plot_history(train_loss_hist, val_loss_hist, f"{config['paths']['save_dir']}/loss.png")
print("Training Complete.")