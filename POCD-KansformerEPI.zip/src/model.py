import torch
import torch.nn as nn
from src.model_layers import KANLinear

class Kansformer(nn.Module):
    def __init__(self, config):
        super(Kansformer, self).__init__()
        d_model = config['model']['hidden_dim']
        n_tokens = config['model'].get('n_tokens', 128)  # tokens per branch for Transformer
        
        # --- Sequence Branch (Inputs: 64 x L) ---
        self.seq_cnn = nn.Sequential(
            nn.Conv1d(64, 128, kernel_size=5, padding=2),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(2),
            nn.Conv1d(128, 64, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(n_tokens),          # Reduce to fixed num tokens
        )
        
        self.bilstm = nn.LSTM(64, 64, batch_first=True, bidirectional=True) # Out: 128
        
        # --- Epigenetic Branch (Inputs: n_epi x Bins) ---
        n_epi = config['data']['n_epigenetic_features']
        self.epi_cnn = nn.Sequential(
            nn.Conv1d(n_epi, 64, kernel_size=11, padding=5),
            nn.BatchNorm1d(64),
            nn.LeakyReLU(),
            nn.MaxPool1d(10),                        # 5000 → 500
            nn.Conv1d(64, 64, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(n_tokens),          # → fixed num tokens
        )
        
        # --- Fusion ---
        self.seq_proj = nn.Linear(128, d_model)
        self.epi_proj = nn.Linear(64, d_model)
        
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=config['model']['num_heads'],
            dim_feedforward=d_model * 4,
            dropout=config['model'].get('dropout', 0.1),
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer, num_layers=config['model']['num_layers']
        )
        
        # --- KAN Prediction Heads ---
        self.fusion_kan = KANLinear(d_model, 128)
        
        # Classification
        self.classifier = nn.Sequential(
            KANLinear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1),
            nn.Sigmoid()
        )
        
        # Regression (Distance)
        self.regressor = nn.Sequential(
            KANLinear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def forward(self, seq, epi):
        # seq: (B, 64, L)
        x_seq = self.seq_cnn(seq)           # (B, 64, n_tokens)
        x_seq = x_seq.permute(0, 2, 1)      # (B, n_tokens, 64)
        x_seq, _ = self.bilstm(x_seq)       # (B, n_tokens, 128)
        x_seq = self.seq_proj(x_seq)        # (B, n_tokens, d_model)
        
        # epi: (B, n_epi, Bins) – already in channel-first format
        x_epi = self.epi_cnn(epi)            # (B, 64, n_tokens)
        x_epi = x_epi.permute(0, 2, 1)      # (B, n_tokens, 64)
        x_epi = self.epi_proj(x_epi)        # (B, n_tokens, d_model)
        
        # Concat: 2*n_tokens sequence elements
        z = torch.cat([x_seq, x_epi], dim=1) # (B, 2*n_tokens, d_model)
        
        # Transformer
        z_trans = self.transformer(z)
        
        # Global Pooling
        z_pool = z_trans.mean(dim=1)
        
        # KAN Heads
        feats = self.fusion_kan(z_pool)
        
        return self.classifier(feats), self.regressor(feats)