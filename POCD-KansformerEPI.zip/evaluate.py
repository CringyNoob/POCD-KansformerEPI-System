import torch
import yaml
import numpy as np
import os
import pickle
from src.model import Kansformer
from src.encoding import POCD_ND_Encoder
from src.interpretation import Interpreter
from src.visualize import plot_cam

# Load Config & Model
with open('configs/config.yaml') as f: config = yaml.safe_load(f)
device = torch.device('cpu')  # Eval on CPU is fine for single samples

# Load encoder
encoder_path = f"{config['paths']['save_dir']}/encoder.pkl"
if os.path.exists(encoder_path):
    with open(encoder_path, 'rb') as f:
        encoder = pickle.load(f)
    print("Loaded encoder from pickle.")
else:
    print("WARNING: encoder.pkl not found, falling back to dummy initialization.")
    encoder = POCD_ND_Encoder(k=config['data']['kmer_size'])
    dummy_pos = ["".join(np.random.choice(['A','C','G','T'], config['data']['sequence_length'])) for _ in range(50)]
    encoder.fit(dummy_pos, dummy_pos, config['data']['sequence_length'])

model = Kansformer(config)
model_path = f"{config['paths']['save_dir']}/model_best.pth"
if not os.path.exists(model_path):
    model_path = f"{config['paths']['save_dir']}/model_final.pth"
model.load_state_dict(torch.load(model_path, map_location=device, weights_only=True))
print(f"Loaded model from {model_path}")

# Interpret one sample
print("Generating Interpretation...")
seq_len = config['data']['sequence_length']
n_epi = config['data']['n_epigenetic_features']
n_bins = config['data']['epigenetic_bins']

sample_seq = "ACGT" * (seq_len // 4)
sample_epi = torch.randn(n_epi, n_bins)   # (n_epi, n_bins) channel-first
seq_enc = encoder.transform(sample_seq)

interp = Interpreter(model)
cam_score = interp.get_cam(seq_enc, sample_epi)

plot_cam(sample_seq, cam_score, "checkpoints/interpretation_cam.png")
print("Done. Check checkpoints/ folder.")